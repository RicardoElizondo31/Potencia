/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package potencia;

import javax.swing.JOptionPane;

/**
 *
 * @author rick_
 */
public class Potencia {

    public static int potencia(int x, int y){
       if(y==0){
         return 1;
       }else if(y<0){
         return potencia(x,y+1)/x;
       }else{
         return x*potencia(x,y-1);
        }
        
}
    
    public static void main(String[] args) {
        int x=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la base"));
        int y=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la potencia"));
        int i=1;
        System.out.println(x+"^"+y+"="+potencia(x,y));
    }
    
}
